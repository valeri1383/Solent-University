const mysql = require("mysql");

const db = mysql.createConnection({
	host: "localhost",
	user: "root",
	password: "",
	database: "Emails_Notifications"
});

db.connect((err)=> {
	if (err) throw err;
	console.log("MySQL is connected!");
  });


  app.get("/index", (req, res) =>{
	
  });

  app.post("/index", (req, res)=>{
	
  });

app.use(express.json());
app.use(express.urlencoded({extended: true}));

db.query("INSERT INTO Emails_Notifications(name, email) VALUES(app.get(req,res))", [req.body.name, req.body.email],(error, results)=>{
    res.render("add_email", {err: error});
});


if(err){ 
    <p>Sorry there was an error adding the staff member</p>
} else { 
    <p>Staff member was added</p>
} 